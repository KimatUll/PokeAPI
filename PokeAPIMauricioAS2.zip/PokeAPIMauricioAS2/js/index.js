let _main = document.querySelector('#contenedor') 

_main.addEventListener('click', pokemon);



function pokemon(){
    fetch("http://pokeapi.co/api/v2/pokemon/257")
    .then((resp)=>resp.json())
    .then((res)=>{
        _main.innerHTML=`
        <div class="kk">
        <h1>${res.name}</h1>
        <img src='${res.sprites.front_shiny}' width='400px'></img>
                <div>
                <h1>Blaziken's base stats</h1>
                <h2><span>${res.stats[0].stat.name}: </span>
                    <span>${res.stats[0].base_stat}</span><br>
                    <span>${res.stats[1].stat.name}: </span>
                    <span>${res.stats[1].base_stat}</span><br>
                    <span>${res.stats[2].stat.name}: </span>
                    <span>${res.stats[2].base_stat}</span><br>
                    <span>${res.stats[3].stat.name}: </span>
                    <span>${res.stats[3].base_stat}</span><br>
                    <span>${res.stats[4].stat.name}: </span>
                    <span>${res.stats[4].base_stat}</span><br>
                    <span>${res.stats[5].stat.name}: </span>
                    <span>${res.stats[5].base_stat}</span></h2>
                </div>
                <div class="kkck">
                <h1>Blaziken's Moveset</h1>
                <h2><span>${res.moves[62].move.name}: </span>
                <span>${res.moves[62].version_group_details[0].level_learned_at}</span><br>
                <span>${res.moves[73].move.name}: </span>
                <span>${res.moves[73].version_group_details[0].level_learned_at}</span><br>
                <span>${res.moves[8].move.name}: </span>
                <span>${res.moves[8].version_group_details[0].level_learned_at}</span><br>
                <span>${res.moves[17].move.name}: </span>
                <span>${res.moves[17].version_group_details[0].level_learned_at}</span><br>
                <span>${res.moves[68].move.name}: </span>
                <span>${res.moves[68].version_group_details[0].level_learned_at}</span></h2>
                </div>
                <div class="kkckmama">
                <h1>Type</h1>
                <h2><span>${res.types[0].type.name}</span><br>
                <span>${res.types[1].type.name}</span></h2>
                </div>
            </div>
            <div class="kk">
            <h1>Evolved from: </h1>
            <img src="./img/comtor.png">
            </div>

        `;
        console.log(res);
        showSlides();
    })
}
var slideIndex = 0;

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("kk");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides, 5000); }